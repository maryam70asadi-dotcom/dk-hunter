
import os, re, time, threading, csv, io
import requests
from flask import Flask, request, jsonify, send_file, Response
from PIL import Image
from io import BytesIO
import pytesseract

app = Flask(__name__)
BASE = "https://api.digikala.com"
HEADERS = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36","Accept":"application/json"}
CODE_RE = re.compile(r"(?<![A-Z0-9])DK[A-Z]{6}(?![A-Z0-9])", re.I)
state = {"running":False,"checked":0,"found":[],"message":"آماده","errors":0}
lock = threading.Lock()

PAGE = r"""<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>شکارچی DK</title>
<style>body{font-family:Tahoma,Arial;background:#f4f6f9;margin:0;padding:16px;color:#222}main{max-width:760px;margin:auto;background:white;padding:18px;border-radius:15px}h1{font-size:23px}.note{background:#fff4d9;padding:12px;border-radius:9px;line-height:1.9;font-size:14px}label{display:block;margin:14px 0 6px}select,input,button{font:inherit;padding:12px;border:1px solid #ccd1d8;border-radius:8px;width:100%;box-sizing:border-box}button{background:#155eef;color:white;border:0;margin-top:15px;font-weight:bold}#status{background:#eef4ff;padding:12px;margin:15px 0;border-radius:8px;line-height:1.8}.item{border-top:1px solid #eee;padding:12px 0;line-height:1.8}a{color:#155eef}</style>
<main><h1>شکارچی کد DK</h1><p>الگوی جست‌وجو: <b>DK + شش حرف انگلیسی</b></p>
<div class="note">نسخه آزمایشی و منتشرنشده. اتصال به API دیجی‌کالا هنوز باید آزمایش شود و ممکن است به‌دلیل تغییرات سایت یا محدودیت دسترسی کار نکند. فقط صفحات عمومی بررسی می‌شوند؛ محدودیت‌های سایت دور زده نمی‌شوند.</div>
<form id="f"><label>محدوده</label><select name="mode"><option value="blackfriday">پیشنهادهای ویژه (آزمایشی)</option><option value="search">جست‌وجوی عمومی (آزمایشی)</option></select><label>تعداد صفحات آزمایشی (۱ تا ۱۰)</label><input name="pages" type="number" min="1" max="10" value="2"><button>شروع اسکن</button></form>
<div id="status">آماده</div><p><a href="/download">دانلود نتایج CSV</a></p><h3>کدهای پیدا شده</h3><div id="results">هنوز نتیجه‌ای نیست.</div></main>
<script>const f=document.getElementById('f'),s=document.getElementById('status'),r=document.getElementById('results');f.onsubmit=async e=>{e.preventDefault();let x=await fetch('/start',{method:'POST',body:new FormData(f)});let j=await x.json();s.textContent=j.ok?'اسکن شروع شد':j.message};async function poll(){try{let j=await(await fetch('/status')).json();s.textContent=j.message+' | محصولات: '+j.checked+' | کدها: '+j.found.length+' | خطاها: '+j.errors;r.innerHTML=j.found.length?j.found.map(a=>'<div class="item"><b>'+a.code+'</b><br>'+a.title+'<br><a target="_blank" href="'+a.url+'">باز کردن محصول</a></div>').join(''):'هنوز کدی پیدا نشده است.'}catch(e){}}setInterval(poll,2500);poll();</script></html>"""

def walk(x):
    if isinstance(x,dict):
        yield x
        for v in x.values(): yield from walk(v)
    elif isinstance(x,list):
        for v in x: yield from walk(v)

def get_json(url, params=None):
    r=requests.get(url,params=params,headers=HEADERS,timeout=20); r.raise_for_status(); return r.json()

def get_ids(payload):
    out=[]; seen=set()
    for d in walk(payload):
        raw=d.get("id") or d.get("product_id")
        if raw is not None and str(raw).isdigit() and any(k in d for k in ("title","title_fa","url","images","images_url")):
            if str(raw) not in seen: seen.add(str(raw)); out.append(str(raw))
    return out

def get_images(payload):
    out=[]; seen=set()
    for d in walk(payload):
        for v in d.values():
            if isinstance(v,str) and v.startswith("http") and "digikala" in v and re.search(r"\.(jpg|jpeg|png|webp)(\?|$)",v,re.I) and v not in seen:
                seen.add(v); out.append(v)
    return out[:20]

def title_for(payload,pid):
    for d in walk(payload):
        if str(d.get("id") or d.get("product_id") or "")==pid:
            return str(d.get("title_fa") or d.get("title") or "محصول "+pid)
    return "محصول "+pid

def worker(mode,pages):
    with lock: state.update(running=True,checked=0,found=[],errors=0,message="در حال دریافت فهرست محصولات…")
    seen=set()
    try:
        for page in range(1,pages+1):
            # These public endpoints are best-effort and may change.
            if mode=="blackfriday": payload=get_json(BASE+"/v1/incredible-offers/products/",{"page":page})
            else: payload=get_json(BASE+"/v1/search/",{"page":page})
            ids=get_ids(payload)
            if not ids:
                with lock: state["message"]="محصولی از این صفحه دریافت نشد؛ ممکن است API تغییر کرده یا دسترسی محدود باشد."
                break
            for pid in ids:
                try:
                    detail=get_json(BASE+f"/v2/product/{pid}/")
                    title=title_for(detail,pid); purl=f"https://www.digikala.com/product/dkp-{pid}/"
                    for img in get_images(detail):
                        try:
                            res=requests.get(img,headers=HEADERS,timeout=20); res.raise_for_status()
                            text=pytesseract.image_to_string(Image.open(BytesIO(res.content)).convert("RGB"),lang="eng",config="--psm 11")
                            for code in CODE_RE.findall(text.upper()):
                                if (code,pid) not in seen:
                                    seen.add((code,pid))
                                    with lock: state["found"].append({"code":code,"title":title,"url":purl})
                        except Exception:
                            with lock: state["errors"]+=1
                    with lock: state["checked"]+=1; state["message"]="در حال بررسی محصولات…"
                    time.sleep(.4)
                except Exception:
                    with lock: state["errors"]+=1; state["checked"]+=1
            time.sleep(.7)
        with lock:
            if state["message"]=="در حال بررسی محصولات…": state["message"]="بررسی صفحات انتخاب‌شده تمام شد."
    except Exception as e:
        with lock: state["message"]="خطا در دریافت اطلاعات: "+str(e)[:160]
    finally:
        with lock: state["running"]=False

@app.get("/")
def home(): return Response(PAGE,mimetype="text/html; charset=utf-8")
@app.post("/start")
def start():
    with lock:
        if state["running"]: return jsonify(ok=False,message="اسکن در حال اجراست.")
    mode=request.form.get("mode","blackfriday"); pages=max(1,min(10,int(request.form.get("pages","2"))))
    threading.Thread(target=worker,args=(mode,pages),daemon=True).start()
    return jsonify(ok=True)
@app.get("/status")
def status():
    with lock: return jsonify(state)
@app.get("/download")
def download():
    with lock: rows=list(state["found"])
    s=io.StringIO(); w=csv.DictWriter(s,fieldnames=["code","title","url"]); w.writeheader(); w.writerows(rows)
    return send_file(BytesIO(s.getvalue().encode("utf-8-sig")),mimetype="text/csv",as_attachment=True,download_name="dk_codes.csv")
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.environ.get("PORT","8080")))
